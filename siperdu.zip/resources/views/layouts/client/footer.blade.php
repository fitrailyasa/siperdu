<footer class="bg-dark text-light img-fluid">
    <div class="d-flex align-items-center p-4">
        <img class="m-3 img img-fluid d-none d-md-block" src="{{ asset('assets/images/logo.png') }}" width="150"
            height="150" alt="Logo">
        <div>
            <p class="mb-2 d-none d-md-block">MTs Negeri 2 Bandar Lampung</p>
            <p class="mb-2 d-none d-md-block">PERPUSTAKAAN AL KINDI</p>
            <p class="mb-2 d-none d-md-block">Jam Operasional Layanan>> Senin-Jumat 08.00 - 16.00 WIB</p>
            <p class="mb-2">Jl. Pulau Pisang No.20, Harapan Jaya, Kec. Sukarame, Kota Bandar Lampung, Lampung
                35131
            </p>
        </div>
    </div>
</footer>
